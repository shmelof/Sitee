from django.db import models
from datetime import datetime
# Create your models here.

class staff(models.Model):
    name = models.CharField(max_length=100)
    telephone = models.CharField(max_length=11)
    mail = models.CharField(max_length=50)
    login = models.CharField(max_length=30)
    password = models.CharField(max_length=30)
    priority = models.CharField(max_length=1, default='1')


class task(models.Model):
    phone = models.CharField(max_length=11)
    procedure = models.CharField(max_length=100)
    dateExecution = models.DateField(default=datetime.now, blank=True)
    staff_id = models.ForeignKey(staff, on_delete=models.CASCADE)

