from django.shortcuts import render
from django.views import View
from django.http import HttpResponseRedirect
from .baza import *


# Create your views here.
def page_not_found_view(request, exception):
    return render(request, '404.html', status=404)


class MainPage(View):
    def get(self,request):
        context = {}
        return render(request, 'main.html', context=context)

class Info(View):
    def get(self,request):
        context = {}
        return render(request, 'info.html', context=context)

class Price(View):
    def get(self,request):
        context = {}
        return render(request, 'price.html', context=context)

class Login(View):
    def get(self, request):

        context = {}
        print("@@")
        print(request)
        return render(request, 'websity.html', context=context)

    def post(self, request):
        entered_login = request.POST.get("login")
        entered_passw = request.POST.get("password")
        users = autoriz(entered_login, entered_passw)
        if not users:
            context = {
                "message": "Введен неверный логин или пароль"
            }
            return render(request, 'websity.html', context=context)
        elif users[0].priority == "0":
            request.session["id_user"] = users[0].id
            request.session["priv_user"] = users[0].priority

            return HttpResponseRedirect('main.html')
        else:
            request.session["id_user"] = users[0].id
            request.session["priv_user"] = users[0].priority
            return HttpResponseRedirect('main.html')

class Record(View):
    def get(self,request):
        selectStaff= get_staff()
        context = {
            'selectStaff': selectStaff
        }
        return render(request, 'record.html', context=context)

    def post(self, request):
        context = {}
        phone = request.POST.get("phone")
        procedure = request.POST.get("procedure")
        dateExecution = request.POST.get("dateExecution")
        staff_id = request.POST.get("staff_id")
        add_task(phone, procedure, dateExecution, staff_id)
        return render(request, 'record.html', context=context)
        return HttpResponseRedirect('main.html')


class Registration(View):
    def get(self,request):
        context = {}
        return render(request, 'websityReg.html', context=context)

    def post(self, request):
        context = {}
        name = request.POST.get("name")
        telephone = request.POST.get("telephone")
        mail = request.POST.get("email")
        loginReg = request.POST.get("loginReg")
        password = request.POST.get("passwordReg")
        loginSeach = loginSearch(loginReg)
        passwordSeach = passwordSearch(password)
        if loginSeach:
            context = {
                "message": "Логин уже занят"
            }
            return render(request, 'websityReg.html', context=context)
        elif passwordSeach:
            context = {
                "message": "Пароль уже занят"
            }
            return render(request, 'websityReg.html', context=context)
        else:
            add_staff(name, telephone, mail, loginReg, password)

            return HttpResponseRedirect('websity.html')