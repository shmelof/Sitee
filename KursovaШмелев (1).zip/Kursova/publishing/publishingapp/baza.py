
from .models import *
from django.db.models import Q
import datetime
from datetime import date


def get_task():
    searchs = task.objects.filter(dateExecution__gte=datetime.datetime.now().date())
    return searchs
    '''print(datetime.datetime.now().date())
    contracts = contract.objects.filter(Q(dateExecution=datetime.datetime.now().date()))
    return contracts'''


def get_task_id(id):
    tasks = task.objects.get(id=id)
    return tasks


def get_staff():
    staffs = staff.objects.all()
    return staffs


def autoriz(login, password):
    users = staff.objects.filter(login=login, password=password)
    return users


def loginSearch(login):
    users = staff.objects.filter(login=login)
    return users


def passwordSearch(password):
    users = staff.objects.filter(password=password)
    return users


def add_task(phone, procedure, dateExecution, staf):

    a_task = task(phone=phone,
                        procedure=procedure,
                        dateExecution=dateExecution,
                        staff_id = staff.objects.get(id=staf))
    a_task.save()

def add_staff(name, telephone, mail, loginReg, password):

    a_staff = staff(name=name,
                        telephone = telephone,
                        mail = mail,
                        login = loginReg,
                        password = password)
    a_staff.save()